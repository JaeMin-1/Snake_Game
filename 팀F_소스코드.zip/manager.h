class Manager
{
public:
    int gameScore(bool check, bool check2, int score);
    int snakeLength(bool check, bool check2, int len);
};