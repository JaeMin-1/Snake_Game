# Snake_game
ncurses를 이용한 snake game
